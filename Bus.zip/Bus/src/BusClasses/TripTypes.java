package BusClasses;

public enum TripTypes{
Round,Single
}