package BusClasses;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlTransient;

@XmlTransient
@XmlSeeAlso({Driver.class,Manager.class})
public abstract class Employee{
    @XmlElement
    private int Age;
    @XmlElement
    private String Name;
    @XmlElement
    private String SSN;
    @XmlElement
    private String Mobile;
    @XmlElement
    private double Salary;
    public Employee(int Age,String Name,String SSN,String Mobile,double Salary)
    {
        this.Age= Age;
        this.Name= Name;
        this.SSN= SSN;
        this.Mobile= Mobile;
        this.Salary= Salary;
    }
    public Employee(){}
} 
