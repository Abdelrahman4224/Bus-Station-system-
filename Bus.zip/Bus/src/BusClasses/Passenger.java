package BusClasses;

import javax.xml.bind.annotation.XmlElement;

public class Passenger{
    @XmlElement
    private int Id;
    @XmlElement
    private String Name;
    @XmlElement
    private String SSN;
    @XmlElement
    private String Mobile;
    public Passenger(){}
    public Passenger(String Name,String SSN,String Mobile){
        this.Name=Name;
        this.SSN=SSN;
        this.Mobile=Mobile;
    }
}
