package BusClasses;

import java.util.ArrayList;

public interface ITrip {
    String getFlavor();
    double getSPrice();
    double getRPrice();
    double getDistance();
    String getFrom();
    String getTo();
    TripTypes getTripType();
    Vehicle getVehicle();
    String getTripName();
    ArrayList<Time> getTimes();
    void setTripType(TripTypes t);
    double getPrice();
    String TripData();
    String EVI();
}
