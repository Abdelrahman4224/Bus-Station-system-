package BusClasses;
import javax.xml.bind.annotation.XmlElement;

public class Driver extends Employee{
    @XmlElement
    private Vehicle v;
    public Driver(int Age,String Name,String SSN,String Mobile,double Salary,Vehicle v)
    {
        super(Age,Name,SSN,Mobile,Salary);
        this.v= v;
    }
    public Vehicle getVehicle(){
        return v;
    }
    public Driver(){}
}
