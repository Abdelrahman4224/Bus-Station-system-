package BusClasses;
import javax.xml.bind.annotation.XmlElement;

public class Ticket{
    @XmlElement
    private Trip trip;
    @XmlElement
    private Time t;
    public Ticket(){}
    public Ticket(Trip tr,Time t,Passenger p){
        try {
            trip=(Trip) tr.getClass().getMethod("clone").invoke(tr);
        } catch (Exception ex) {
            trip=tr;
        }
       this.t=t;
       this.Passenger=p;
    }
    private Passenger Passenger;
}
