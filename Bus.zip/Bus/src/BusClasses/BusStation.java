package BusClasses;
import java.io.File;
import java.io.FileOutputStream;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

public class BusStation{
    public static Station s=new Station();
    /**
     * @param args the command line arguments
     */
    public static void save()
    {
        JAXBContext contextObj;  
        try {
            
            contextObj = JAXBContext.newInstance(Station.class);
            Marshaller marshallerObj = contextObj.createMarshaller();
            marshallerObj.marshal(s, new FileOutputStream("BusStationData.xml"));
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }
    public static void load()
    {
        JAXBContext contextObj;  
        try {
            
            contextObj = JAXBContext.newInstance(Station.class);
           Unmarshaller marshallerObj = contextObj.createUnmarshaller();
            File f=new File("BusStationData.xml");
            s=(Station) marshallerObj.unmarshal(f);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }
    public static Time getTimeById(int id)
    {
        for(int i=0;i<s.AllowedTimes.size();i++)
            if(s.AllowedTimes.get(i).getId()==id)
                return s.AllowedTimes.get(i);
        return null;
    }
    public static Vehicle getVehicleById(int id)
    {
        for(int i=0;i<s.Vehicles.size();i++)
            if(s.Vehicles.get(i).getId()==id)
                return s.Vehicles.get(i);
        return null;
    }
}
