package BusClasses;

public enum CarTypes{
Bus,MiniBus,Limousine
}