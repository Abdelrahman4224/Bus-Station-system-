package BusClasses;
import java.util.ArrayList;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlTransient;

@XmlTransient
@XmlSeeAlso({InternalTrip.class,ExternalTrip.class})
public abstract class Trip implements ITrip{
    @XmlElement
    private String Flavor;
    @XmlElement
    private double SPrice;
    @XmlElement
    private double RPrice;
    @XmlElement
    private double Distance;
    @XmlElement
    private String From;
    @XmlElement
    private String To;
    @XmlElement
    private TripTypes TripType;
    @XmlElement
    private String EVI;
    @XmlElement
    private Vehicle v;
    @XmlElement
    private ArrayList<Time> Times=new ArrayList<Time>();
    public Trip(){}
    public Trip(String Flavor,double SPrice,double RPrice,double Distance,String From,String To,TripTypes TripType,ArrayList<Time> Times,Vehicle v){
        this.Distance=Distance;
        this.Flavor=Flavor;
        this.From=From;
        this.RPrice=RPrice;
        this.SPrice=SPrice;
        this.To=To;
        this.TripType=TripType;
        this.v=v;
        this.Times=Times;
    }
    public String getFlavor()
    {
        return Flavor;
    }
    public double getSPrice()
    {
        return SPrice;
    }
    public double getRPrice()
    {
        return RPrice;
    }
    public double getDistance(){
        return Distance;
    }
    public String getFrom(){
        return From;
    }
    public String getTo(){
        return To;
    }
    public TripTypes getTripType(){
        return TripType;
    }
    
    public Vehicle getVehicle(){
        return v;
    }
    public String getTripName()
    {
        return this.From +' '+this.To;
    }
    public ArrayList<Time> getTimes()
    {
        return this.Times;
    }
    public String toString(){
        return getTripName();
    }
    public void setTripType(TripTypes t){
        this.TripType=t;
    }
    public double getPrice()
    {
        if(this.TripType==TripTypes.Round)
        {
            return RPrice;
        }
        else{
            return SPrice;
        }
    }
    public String TripData()
    {
        return "Distance: "+this.Distance
                +"\n"+"Flavor: "+this.Flavor
                +"\n"+"EVI: "+this.EVI()
                +"\n\n"
                +"Car Data:"
                +"\nType: "+this.v.getCarType()
                +"\nModel: "+this.v.getModel()
                +"\nColor: "+this.v.getColor()
                +"\nPlates-Number: "+this.v.getPlates();
    }
    abstract public String EVI();
}
