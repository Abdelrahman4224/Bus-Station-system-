package BusClasses;

import javax.xml.bind.annotation.XmlElement;

public class Time {
    @XmlElement
    private static int autoSetVal=0;
    @XmlElement
    private int id;
    @XmlElement
    private String Start;
    @XmlElement
    private String End;
    public Time(){}
    public Time(String s,String e)
    {
        id=++autoSetVal;
        this.Start=s;
        this.End=e;
    }
    public String toString(){
        return "Start at "+Start+" End at "+End;
    }
    public int getId()
    {
        return id;
    }
}
