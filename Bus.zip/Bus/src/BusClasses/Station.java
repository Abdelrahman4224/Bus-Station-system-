package BusClasses;
import java.util.ArrayList;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Station{
    @XmlElement
    public ArrayList<Vehicle> Vehicles=new ArrayList<Vehicle>();
    @XmlElement
    public ArrayList<Employee> Employees=new ArrayList<Employee>();
    @XmlElement
    public ArrayList<Passenger> Passengers=new ArrayList<Passenger>();
    @XmlElement
    public ArrayList<Trip> Trips=new ArrayList<Trip>();
    @XmlElement
    public ArrayList<Ticket> Tickets=new ArrayList<Ticket>();
    @XmlElement
    public ArrayList<Time> AllowedTimes=new ArrayList<Time>();
    public ArrayList<Vehicle> getVehicles(){
        ArrayList<Vehicle> AllowedVehicles=new ArrayList<Vehicle>();
        for(int i=0;i<Vehicles.size();i++)
        {
            if(!((Vehicle)Vehicles.get(i)).getReserved()&&((Vehicle)Vehicles.get(i)).getIsForDriver())
                AllowedVehicles.add((Vehicle)Vehicles.get(i));
        }
        return AllowedVehicles;
    }
    public ArrayList<Vehicle> getIdleVehicles(){
        ArrayList<Vehicle> AllowedVehicles=new ArrayList<Vehicle>();
        for(int i=0;i<Vehicles.size();i++)
        {
            if(!((Vehicle)Vehicles.get(i)).getIsForDriver())
                AllowedVehicles.add((Vehicle)Vehicles.get(i));
        }
        return AllowedVehicles;
    }
}

