package BusClasses;
import javax.xml.bind.annotation.XmlElement;

public class Vehicle{
    @XmlElement
    private static int autoSetVal=0;
    @XmlElement
    private int id;
    @XmlElement
    private CarTypes Type;
    @XmlElement
    private String Model;
    @XmlElement
    private String Year;
    @XmlElement
    private String CC;
    @XmlElement
    private String Color;
    @XmlElement
    private String Plates;
    public Vehicle(){}
    public Vehicle(CarTypes Type,String Model,String Year,String CC,String Color,String Plates){
        id=++autoSetVal;
        this.Type= Type;
        this.Model= Model;
        this.Year= Year;
        this.CC= CC;
        this.Color= Color;
        this.Plates= Plates;
    }
    @XmlElement
    private boolean IsReserved=false;
    @XmlElement
    private boolean IsForDriver=false;
    public CarTypes getCarType()
    {
        return Type;
    }
    public String getModel()
    {
        return Model;
    }
    public String getCC()
    {
        return CC;
    }
    public int getId()
    {
        return id;
    }
    public String getColor()
    {
        return Color;
    }
    public String getPlates()
    {
        return Plates;
    }
    public boolean getReserved()
    {
        return this.IsReserved;
    }
    public boolean setReserved(boolean b)
    {
        if(this.IsReserved==true&&b==true)
            return false;
        this.IsReserved=b;
        return true;
    }
    public boolean getIsForDriver()
    {
        return this.IsForDriver;
    }
    public boolean setIsForDriver(boolean b)
    {
        if(this.IsForDriver==true&&b==true)
            return false;
        this.IsForDriver=b;
        return true;
    }
    public String toString(){
        return Type+"-"+Model+"-"+Color+"-"+Plates;
    }
}
