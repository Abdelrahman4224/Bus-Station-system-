package BusClasses;

public class Manager extends Employee{
    public Manager(){}
    public Manager(int Age,String Name,String SSN,String Mobile,double Salary)
    {
        super(Age,Name,SSN,Mobile,Salary);
    }
}
