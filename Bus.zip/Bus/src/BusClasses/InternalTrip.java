package BusClasses;
import java.util.ArrayList;

public class InternalTrip extends Trip{
    public InternalTrip(){}
    public InternalTrip(String Flavor,double SPrice,double RPrice,double Distance,String From,String To,TripTypes TripType,ArrayList<Time> Times,Vehicle v){
        super(Flavor,SPrice,RPrice,Distance,From,To,TripType,Times,v);
    }
    public double getPrice()
    {
        return super.getPrice();
    }
    public String EVI(){
        return "Internal";
    }
    
}
