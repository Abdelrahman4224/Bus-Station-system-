package BusStation;

import BusClasses.*;
import java.util.ArrayList;
import java.util.EnumSet;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

public class AddVehicle extends Application {
    
@Override
    public void start(final Stage stage) {
        BorderPane basePane=new BorderPane();
        VBox hb=new VBox(8);
        hb.setPadding(new Insets(15, 12, 15, 12));
        final ComboBox Type=new ComboBox(FXCollections.observableArrayList(EnumSet.allOf(CarTypes.class)));
        Type.setMinSize(150, 20);
        final TextField Model=new TextField("Model");
        final TextField Year=new TextField("Year");
        final TextField CC=new TextField("CC");
        final TextField Color=new TextField("Color");
        final TextField Plates=new TextField("Plates");
        Button add=new Button("Add");
        add.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
                CarTypes ct=(CarTypes)Type.getValue();
                String m=Model.getText();
                String y=Year.getText();
                String cc=CC.getText();
                String color=Color.getText();
                String p=Plates.getText();
                if(ct==null||m.equals("")||y.equals("")||cc.equals("")||color.equals("")||p.equals(""))
                {
                    JOptionPane.showMessageDialog(null, "Please Fill All Data");
                    return;
                } 
                BusStation.s.Vehicles.add(new Vehicle(ct,m,y,cc,color,p));
                stage.close();
            }
        });
        hb.getChildren().addAll(Type,Model,Year,CC,Color,Plates,add);
        basePane.setCenter(hb);
        Scene s=new Scene(basePane);
        stage.setScene(s);
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
