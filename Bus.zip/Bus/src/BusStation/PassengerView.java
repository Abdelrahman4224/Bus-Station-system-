package BusStation;

import BusClasses.*;
import java.util.ArrayList;
import java.util.EnumSet;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javax.swing.JOptionPane;


public class PassengerView extends Application {
    
    @Override
    public void start(final Stage stage) {
        BorderPane basePane=new BorderPane();
        VBox hb=new VBox(8);
        hb.setPadding(new Insets(15, 12, 15, 12));
        final TextField Name=new TextField("Name");
        final TextField SSN=new TextField("SSN");
        final TextField Mobile=new TextField("Mobile");
        final ComboBox trips=new ComboBox(FXCollections.observableArrayList(BusStation.s.Trips));
        final ComboBox Times=new ComboBox(FXCollections.observableArrayList(new ArrayList<Time>()));
        Button reserve=new Button("Reserve");
        ComboBox tripTypes=new ComboBox(FXCollections.observableArrayList(EnumSet.allOf(TripTypes.class)));
        final Label priceLabel = new Label();
        trips.setMinSize(150, 20);
        Times.setMinSize(150, 20);
        tripTypes.setMinSize(150, 20);
        priceLabel.setMinHeight(200);
        trips.valueProperty().addListener(new ChangeListener<Trip>() {
            @Override public void changed(ObservableValue<? extends Trip> ov, Trip oldVal, Trip newVal) {
                Times.setItems(FXCollections.observableArrayList(newVal.getTimes()));
                System.out.println(newVal.toString());
            }    
        });
        tripTypes.valueProperty().addListener(new ChangeListener<TripTypes>() {
            @Override public void changed(ObservableValue<? extends TripTypes> ov, TripTypes oldVal, TripTypes newVal) {
                try{
                    Trip t=(Trip)trips.getValue();
                    t.setTripType(newVal);
                    priceLabel.setText("cost: "+String.valueOf(t.getPrice())+"\n"+t.TripData());
                }
                catch(Exception ex)
                {
                    JOptionPane.showMessageDialog(null, "Error While retrieving data,\nplease ensure that system data are entered correctly");
                }
            }    
        });
        reserve.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
                Trip t=(Trip)trips.getValue();
                Time time=(Time)Times.getValue();
                String s=Name.getText();
                String ssn=SSN.getText();
                String m=Mobile.getText();
                if(t==null||time==null||s.equals("")||ssn.equals("")||m.equals(""))
                {
                    JOptionPane.showMessageDialog(null, "Please Fill All Data");
                    return;
                }
                BusStation.s.Tickets.add(new Ticket(t,time,new Passenger(s,ssn,m)));
                stage.close();
            }
        });
        hb.getChildren().addAll(Name,SSN,Mobile,trips,Times,tripTypes,priceLabel,reserve);
        basePane.setCenter(hb);
        Scene s=new Scene(basePane);
        stage.setScene(s);
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
