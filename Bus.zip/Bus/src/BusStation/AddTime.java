package BusStation;

import BusClasses.*;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

public class AddTime extends Application {
    
@Override
    public void start(final Stage stage) {
        BorderPane basePane=new BorderPane();
        VBox hb=new VBox(8);
        hb.setPadding(new Insets(15, 12, 15, 12));
        final TextField from=new TextField("From");
        final TextField to=new TextField("To");
        Button add=new Button("Add");
        add.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
                String f=from.getText();
                String t=to.getText();
                if(f.equals("")||t.equals(""))
                {
                    JOptionPane.showMessageDialog(null, "Please Fill All Data");
                    return;
                }
                BusStation.s.AllowedTimes.add(new Time(f,t));
                stage.close();
            }
        });
        hb.getChildren().addAll(from,to,add);
        basePane.setCenter(hb);
        Scene s=new Scene(basePane);
        stage.setScene(s);
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
