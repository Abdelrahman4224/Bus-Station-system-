package BusStation;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class AddEmployee extends Application {
    
@Override
    public void start(Stage stage) {
        BorderPane basePane=new BorderPane();
        VBox hb=new VBox(8);
        hb.setPadding(new Insets(15, 12, 15, 12));
        Button Driver=new Button("Driver");
        Button Manager=new Button("Manager");
        Driver.setMinSize(100,25);
        Manager.setMinSize(100,25);
        final Stage st=new Stage();
        st.initModality(Modality.WINDOW_MODAL);
        st.initOwner(stage);
        Driver.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
                new AddDriver().start(st);
            }
        });
        Manager.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
                new AddManager().start(st);
            }
        });
        hb.getChildren().addAll(Driver,Manager);
        basePane.setCenter(hb);
        Scene s=new Scene(basePane);
        stage.setScene(s);
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
