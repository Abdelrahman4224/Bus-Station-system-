package BusStation;

import java.util.Date;
import java.util.EnumSet;
import javafx.scene.control.Button;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;


public class ManagerView extends Application {
    
    @Override
    public void start(Stage stage) {
        BorderPane basePane=new BorderPane();
        VBox hb=new VBox(8);
        hb.setPadding(new Insets(15, 12, 15, 12));
        Button addTrip=new Button("Add New Trip");
        Button editTrip=new Button("Edit Trip");
        Button addTime=new Button("Add Time");
        Button addEmployee=new Button("Add Employee");
        Button addVehicle=new Button("Add Vehicle");
        addTrip.setMinSize(100, 25);
        editTrip.setMinSize(100, 25);
        addTime.setMinSize(100, 25);
        addEmployee.setMinSize(100, 25);
        addVehicle.setMinSize(100, 25);
        final Stage st=new Stage();
        st.initModality(Modality.WINDOW_MODAL);
        st.initOwner(stage);
        addTrip.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
                new AddTrip().start(st);
            }
        });
        editTrip.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
                new EditTrip().start(st);
            }
        });
        addTime.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
                new AddTime().start(st);
            }
        });
        addEmployee.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
                new AddEmployee().start(st);
            }
        });
        addVehicle.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
                new AddVehicle().start(st);
            }
        });
        hb.getChildren().addAll(addTrip,editTrip,addTime,addEmployee,addVehicle);
        basePane.setCenter(hb);
        Scene s=new Scene(basePane);
        stage.setScene(s);
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
