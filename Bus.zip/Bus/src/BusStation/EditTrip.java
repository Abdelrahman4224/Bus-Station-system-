package BusStation;

import BusClasses.*;
import java.util.ArrayList;
import java.util.EnumSet;
import javafx.scene.control.Button;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javax.swing.JOptionPane;


public class EditTrip extends Application {
    
    @Override
    public void start(final Stage stage) {
        BorderPane basePane=new BorderPane();
        VBox hb=new VBox(8);
        hb.setPadding(new Insets(15, 12, 15, 12));
        final TextField flavor=new TextField("Flavor");
        final TextField sPrice=new TextField("SPrice");
        final TextField rPrice=new TextField("RPrice");
        final TextField distance=new TextField("Distance");
        final TextField from=new TextField("From");
        final TextField to=new TextField("To");
        final ComboBox tripTypes=new ComboBox(FXCollections.observableArrayList(EnumSet.allOf(TripTypes.class)));
        final ComboBox IVE=new ComboBox(FXCollections.observableArrayList("Internal","External"));
        final ComboBox trips=new ComboBox(FXCollections.observableArrayList(BusStation.s.Trips));
        IVE.setMinSize(150, 20);
        tripTypes.setMinSize(150, 20);
        //final ComboBox Times=new ComboBox(FXCollections.observableArrayList(BusStation.s.AllowedTimes));
        final ListView<Time> Times = new ListView<>(FXCollections.observableArrayList(BusStation.s.AllowedTimes));
        Times.setMinSize(150, 20);
        final ComboBox Vehicles=new ComboBox(FXCollections.observableArrayList(BusStation.s.getVehicles()));
        Vehicles.setMinSize(150, 20);
        Times.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        Button add=new Button("Edit");
        Button del=new Button("Delete");
        trips.setMinSize(150, 20);
        trips.valueProperty().addListener(new ChangeListener<Trip>() {
            @Override public void changed(ObservableValue<? extends Trip> ov, Trip oldVal, Trip newVal) {
                ArrayList<Time> times=newVal.getTimes();
                for(int i=0;i<times.size();i++)
                    Times.getSelectionModel().select(BusStation.getTimeById(times.get(i).getId()));
                flavor.setText(newVal.getFlavor());
                sPrice.setText(String.valueOf(newVal.getSPrice()));
                rPrice.setText(String.valueOf(newVal.getRPrice()));
                distance.setText(String.valueOf(newVal.getDistance()));
                from.setText(newVal.getFrom());
                to.setText(newVal.getTo());
                IVE.getSelectionModel().select(newVal.EVI());
                tripTypes.getSelectionModel().select(newVal.getTripType());
                Vehicles.getSelectionModel().select(newVal.getVehicle());
                setIndex(BusStation.s.Trips.indexOf(newVal));
            }    
        });
        del.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
                BusStation.getVehicleById(BusStation.s.Trips.get(EditIndex).getVehicle().getId()).setReserved(false);
                BusStation.s.Trips.remove(BusStation.s.Trips.get(EditIndex));
                stage.close();
            }
        });
        add.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
                BusStation.getVehicleById(BusStation.s.Trips.get(EditIndex).getVehicle().getId()).setReserved(false);
                BusStation.s.Trips.remove(BusStation.s.Trips.get(EditIndex));
                ObservableList<Time> t=Times.getSelectionModel().getSelectedItems();
                String f=flavor.getText();
                String sP=sPrice.getText();
                String rP=rPrice.getText();
                String d=distance.getText();
                String fr=from.getText();
                String toText=to.getText();
                TripTypes tt=(TripTypes)tripTypes.getValue();
                ArrayList<Time> ti=(ArrayList<Time>)t;
                Vehicle v=(Vehicle)Vehicles.getValue();
                double iD,iSP,iRP;
                if(trips==null||IVE==null||f.equals("")||sP.equals("")||rP.equals("")||d.equals("")||fr.equals("")||toText.equals("")||tt==null||ti.size()==0||v==null)
                {
                    JOptionPane.showMessageDialog(null, "Please Fill All Data");
                    return;
                }
                try{
                    iD=Double.parseDouble(d);
                    iSP=Double.parseDouble(sP);
                    iRP=Double.parseDouble(rP);
                }catch(Exception ex)
                {
                    JOptionPane.showMessageDialog(null, "Distance, Round Price and Single Price only can be a numeric value"); 
                    return;
                }
                String ive=(String)IVE.getValue();
                if(ive.equals("Internal"))
                    BusStation.s.Trips.add(new InternalTrip(f,iSP,iRP,iD,fr,toText,tt,ti,v));
                else
                    BusStation.s.Trips.add(new ExternalTrip(f,iSP,iRP,iD,fr,toText,tt,ti,v));

                ((Vehicle)Vehicles.getValue()).setReserved(true);
                stage.close();
                /*for(int i=0;i<aa.size();i++)
                    System.out.println(aa.get(i));*/
            }
        });
        hb.getChildren().addAll(trips,IVE,flavor,sPrice,rPrice,distance,from,to,tripTypes,Times,Vehicles,add,del);
        basePane.setCenter(hb);
        Scene s=new Scene(basePane);
        stage.setScene(s);
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    public static int EditIndex=-1;
    public static void setIndex(int i)
    {
        EditIndex=i;
    }
    
}
