package BusStation;

import BusClasses.*;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

public class AddDriver extends Application {
    
@Override
    public void start(final Stage stage) {
        BorderPane basePane=new BorderPane();
        VBox hb=new VBox(8);
        hb.setPadding(new Insets(15, 12, 15, 12));
        final TextField Age=new TextField("Age");
        final TextField Name=new TextField("Name");
        final TextField SSN=new TextField("SSN");
        final TextField Mobile=new TextField("Mobile");
        final TextField Salary=new TextField("Salary");
        final ComboBox Vehicles=new ComboBox(FXCollections.observableArrayList(BusStation.s.getIdleVehicles()));
        Vehicles.setMinSize(150, 20);
        Button add=new Button("Add");
        add.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
                String age=Age.getText();
                String name=Name.getText();
                String ssn=SSN.getText();
                String m=Mobile.getText();
                String s=Salary.getText();
                Vehicle v=(Vehicle)Vehicles.getValue();
                int iAge;
                double iS;
                if(age.equals("")||name.equals("")||ssn.equals("")||m.equals("")||s.equals("")||v==null)
                {
                    JOptionPane.showMessageDialog(null, "Please Fill All Data");
                    return;
                }
                try{
                    iAge=Integer.parseInt(age);
                    iS=Double.parseDouble(s);
                }catch(Exception ex)
                {                    
                    JOptionPane.showMessageDialog(null, "Age and Salary only can be a numeric value"); 
                    return;
                }
                BusStation.s.Employees.add(new Driver(iAge,name,ssn,m,iS,v));                
                ((Vehicle)Vehicles.getValue()).setIsForDriver(true);
                stage.close();
            }
        });
        hb.getChildren().addAll(Age,Name,SSN,Mobile,Salary,Vehicles,add);
        basePane.setCenter(hb);
        Scene s=new Scene(basePane);
        stage.setScene(s);
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
