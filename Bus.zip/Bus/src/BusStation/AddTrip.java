package BusStation;

import BusClasses.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.EnumSet;
import javafx.scene.control.Button;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javax.swing.JOptionPane;


public class AddTrip extends Application {
    
    @Override
    public void start(final Stage stage) {
        BorderPane basePane=new BorderPane();
        VBox hb=new VBox(8);
        hb.setPadding(new Insets(15, 12, 15, 12));
        final TextField flavor=new TextField("Flavor");
        final TextField sPrice=new TextField("SPrice");
        final TextField rPrice=new TextField("RPrice");
        final TextField distance=new TextField("Distance");
        final TextField from=new TextField("From");
        final TextField to=new TextField("To");
        final ComboBox tripTypes=new ComboBox(FXCollections.observableArrayList(EnumSet.allOf(TripTypes.class)));
        final ComboBox IVE=new ComboBox(FXCollections.observableArrayList("Internal","External"));
        IVE.setMinSize(150, 20);
        tripTypes.setMinSize(150, 20);
        //final ComboBox Times=new ComboBox(FXCollections.observableArrayList(BusStation.s.AllowedTimes));
        final ListView<Time> Times = new ListView<>(FXCollections.observableArrayList(BusStation.s.AllowedTimes));
        Times.setMinSize(150, 20);
        final ComboBox Vehicles=new ComboBox(FXCollections.observableArrayList(BusStation.s.getVehicles()));
        Vehicles.setMinSize(150, 20);
        Times.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        Button add=new Button("Add");
        add.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
                ObservableList<Time> t=Times.getSelectionModel().getSelectedItems();
                String f=flavor.getText();
                String sP=sPrice.getText();
                String rP=rPrice.getText();
                String d=distance.getText();
                String fr=from.getText();
                String toText=to.getText();
                TripTypes tt=(TripTypes)tripTypes.getValue();
                ArrayList<Time> ti;
                if (t instanceof ArrayList<?>) {
                    ti = (ArrayList<Time>) t;
                } else {
                    ti = new ArrayList<>(t);
                }
                Vehicle v=(Vehicle)Vehicles.getValue();
                double iD,iSP,iRP;
                if(IVE==null||f.equals("")||sP.equals("")||rP.equals("")||d.equals("")||fr.equals("")||toText.equals("")||tt==null||ti.size()==0||v==null)
                {
                    JOptionPane.showMessageDialog(null, "Please Fill All Data");
                    return;
                }
                try{
                    iD=Double.parseDouble(d);
                    iSP=Double.parseDouble(sP);
                    iRP=Double.parseDouble(rP);
                }catch(Exception ex)
                {
                    JOptionPane.showMessageDialog(null, "Distance, Round Price and Single Price only can be a numeric value"); 
                    return;
                }
                String ive=(String)IVE.getValue();
                if(ive.equals("Internal"))
                    BusStation.s.Trips.add(new InternalTrip(f,iSP,iRP,iD,fr,toText,tt,ti,v));
                else
                    BusStation.s.Trips.add(new ExternalTrip(f,iSP,iRP,iD,fr,toText,tt,ti,v));

                ((Vehicle)Vehicles.getValue()).setReserved(true);
                stage.close();
                /*for(int i=0;i<aa.size();i++)
                    System.out.println(aa.get(i));*/
            }
        });
        hb.getChildren().addAll(IVE,flavor,sPrice,rPrice,distance,from,to,tripTypes,Times,Vehicles,add);
        basePane.setCenter(hb);
        Scene s=new Scene(basePane);
        stage.setScene(s);
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
