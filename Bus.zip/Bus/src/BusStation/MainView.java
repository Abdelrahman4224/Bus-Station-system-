package BusStation;

import BusClasses.BusStation;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

public class MainView extends Application {
    
@Override
    public void start(Stage stage) {
        BusStation.load();
        BorderPane basePane=new BorderPane();
        VBox hb=new VBox(8);
        hb.setPadding(new Insets(15, 12, 15, 12));
        Button manager=new Button("Manager View");
        Button passenger=new Button("Passenger View");
        Button save=new Button("Save");
        manager.setMinSize(100,25);
        passenger.setMinSize(100,25);
        save.setMinSize(100,25);
        final Stage st=new Stage();
        st.initModality(Modality.WINDOW_MODAL);
        st.initOwner(stage);
        manager.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
                new ManagerView().start(st);
            }
        });
        passenger.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
                new PassengerView().start(st);
            }
        });
        save.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
                BusStation.save();
            }
        });
        hb.getChildren().addAll(manager,passenger,save);
        basePane.setCenter(hb);
        Scene s=new Scene(basePane);
        stage.setScene(s);
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
